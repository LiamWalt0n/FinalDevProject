package view;

import javafx.scene.layout.BorderPane;
import javafx.scene.layout.FlowPane;
import javafx.scene.layout.HBox;
import javafx.scene.layout.StackPane;
import javafx.scene.layout.VBox;
import model.Schedule;
import model.Venue;
import model.Module;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.FileWriter;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.util.Iterator;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.control.Button;
import javafx.scene.control.ComboBox;
import javafx.scene.control.Label;
import javafx.scene.control.ListView;
import javafx.scene.control.TextField;
import javafx.scene.control.Tab;
import javafx.scene.control.TabPane;
import javafx.scene.control.ToolBar;

//You may change this class to extend another type if you wish
public class ConfirmBookingRootPane extends BorderPane implements ActionListener {

	private ComboBox<String> selectCourseComboBox;
	private ListView<String> timeListView;
	private ListView<String> timeSelected;
	private ListView<String> seatSelectedListView;
	private Button CreateProfilebtn;
	private TabPane tabPane;
	private TextField TimeOneTextField;
	private TextField SeatsTwoTextField;
	private Button selectTime;
	private Button removeTime; 
	private Button selectSeat; 
	private Button seatRemove; 
	private Button SubmitButton;
	private Button SubmitReserveButton;
	private Button CreateAccButton;
	private Button LoginButton;
	FileWriter fileWriter;

	public ConfirmBookingRootPane() {
		// Creates the toolbar at the top of the program

		ToolBar toolbar = new ToolBar(new Button("File"), new Button("Help"));

		this.setTop(toolbar);


		// Create a new tab in tab pane

		tabPane = new TabPane();

		//

		Tab createProfileTab = new Tab();
		createProfileTab.setText("Booking Details");
		createProfileTab.setClosable(false);

		StackPane createProfile_Content = new StackPane();

		// VBox is a vertical box set up run vertically down the first tab for info to
		// be entered
		VBox createProfile_Column = new VBox();
		createProfile_Column.setPrefSize(500, 500);
		createProfile_Column.setMinSize(500, 500);
		createProfile_Column.setPadding(new Insets(150, 20, 20, 75));

		// Hbox to create a course label plus combobox for selecting seat

		HBox selectVenue_HBox = new HBox();
		selectVenue_HBox.setPadding(new Insets(5, 0, 5, 0));
		Label selectVenueLabel = new Label("Venue:*");
		selectVenueLabel.setMinWidth(160);
		selectVenueLabel.setMinHeight(20);
		selectVenueLabel.setAlignment(Pos.CENTER_RIGHT);
		selectVenueLabel.setStyle("-fx-font-weight: Bold");
		selectVenueLabel.setPadding(new Insets(0, 12, 0, 12));
		selectCourseComboBox = new ComboBox<String>();
		selectCourseComboBox.setMinWidth(160);
		selectVenue_HBox.getChildren().add(selectVenueLabel);
		selectVenue_HBox.getChildren().add(selectCourseComboBox);
		createProfile_Column.getChildren().add(selectVenue_HBox);

		// Hbox to create a Party number label and a text box

		HBox inputPNumber_HBox = new HBox();
		inputPNumber_HBox.setPadding(new Insets(5, 0, 5, 0));
		Label inputPNumberLabel = new Label("Input Party Number:*");
		inputPNumberLabel.setMinWidth(160);
		inputPNumberLabel.setMinHeight(20);
		inputPNumberLabel.setAlignment(Pos.CENTER_RIGHT);
		inputPNumberLabel.setPadding(new Insets(0, 12, 0, 12));
		inputPNumberLabel.setStyle("-fx-font-weight: Bold");
		TextField inputPNumberTextField = new TextField();
		inputPNumberTextField.setMinWidth(160);
		inputPNumber_HBox.getChildren().add(inputPNumberLabel);
		inputPNumber_HBox.getChildren().add(inputPNumberTextField);
		createProfile_Column.getChildren().add(inputPNumber_HBox);

		// Hbox to create a First name label and a text box

		HBox inputFirstName_HBox = new HBox();
		inputFirstName_HBox.setPadding(new Insets(5, 0, 5, 0));
		Label inputFirstNameLabel = new Label("Input First Name:*");
		inputFirstNameLabel.setMinWidth(160);
		inputFirstNameLabel.setMinHeight(20);
		inputFirstNameLabel.setAlignment(Pos.CENTER_RIGHT);
		inputFirstNameLabel.setPadding(new Insets(0, 12, 0, 12));
		inputFirstNameLabel.setStyle("-fx-font-weight: Bold");
		TextField firstName = new TextField();
		firstName.setMinWidth(160);
		inputFirstName_HBox.getChildren().add(inputFirstNameLabel);
		inputFirstName_HBox.getChildren().add(firstName);
		createProfile_Column.getChildren().add(inputFirstName_HBox);

		// Hbox to create a second name label and a text box

		HBox inputSurname_HBox = new HBox();
		inputSurname_HBox.setPadding(new Insets(5, 0, 5, 0));
		Label inputSurnameLabel = new Label("Input Family Name:*");
		inputSurnameLabel.setMinWidth(160);
		inputSurnameLabel.setMinHeight(20);
		inputSurnameLabel.setAlignment(Pos.CENTER_RIGHT);
		inputSurnameLabel.setPadding(new Insets(0, 12, 0, 12));
		inputSurnameLabel.setStyle("-fx-font-weight: Bold");
		TextField inputSurnameTextField = new TextField();
		inputSurnameTextField.setMinWidth(160);
		inputSurname_HBox.getChildren().add(inputSurnameLabel);
		inputSurname_HBox.getChildren().add(inputSurnameTextField);
		createProfile_Column.getChildren().add(inputSurname_HBox);

		// Hbox to create an email label and a text box

		HBox inputEmail_HBox = new HBox();
		inputEmail_HBox.setPadding(new Insets(5, 0, 5, 0));
		Label inputEmailLabel = new Label("Input Email Address:*");
		inputEmailLabel.setMinWidth(160);
		inputEmailLabel.setMinHeight(20);
		inputEmailLabel.setAlignment(Pos.CENTER_RIGHT);
		inputEmailLabel.setPadding(new Insets(0, 12, 0, 12));
		inputEmailLabel.setStyle("-fx-font-weight: Bold");
		TextField inputEmailTextField = new TextField();
		inputEmailTextField.setMinWidth(160);
		inputEmail_HBox.getChildren().add(inputEmailLabel);
		inputEmail_HBox.getChildren().add(inputEmailTextField);
		createProfile_Column.getChildren().add(inputEmail_HBox);

		HBox inputNumber_HBox = new HBox();
		inputEmail_HBox.setPadding(new Insets(5, 0, 5, 0));
		Label inputNumberLabel = new Label("Input Phone Number:");
		inputNumberLabel.setMinWidth(160);
		inputNumberLabel.setMinHeight(20);
		inputNumberLabel.setAlignment(Pos.CENTER_RIGHT);
		inputNumberLabel.setPadding(new Insets(0, 12, 0, 12));
		inputNumberLabel.setStyle("-fx-font-weight: Bold");
		TextField inputNumberTextField = new TextField();
		inputNumberTextField.setMinWidth(160);
		inputNumber_HBox.getChildren().add(inputNumberLabel);
		inputNumber_HBox.getChildren().add(inputNumberTextField);
		createProfile_Column.getChildren().add(inputNumber_HBox);

		// Hbox to create a date label and a text box to enter the data

		HBox inputDate_HBox = new HBox();
		inputDate_HBox.setPadding(new Insets(5, 0, 5, 0));
		Label inputDateLabel = new Label("Meal Date DD/MM/YY:*");
		inputDateLabel.setMinWidth(160);
		inputDateLabel.setMinHeight(20);
		inputDateLabel.setAlignment(Pos.CENTER_RIGHT);
		inputDateLabel.setPadding(new Insets(0, 12, 0, 12));
		inputDateLabel.setStyle("-fx-font-weight: Bold");
		TextField inputDateTextField = new TextField();
		inputDateTextField.setMinWidth(160);
		inputDate_HBox.getChildren().add(inputDateLabel);
		inputDate_HBox.getChildren().add(inputDateTextField);
		createProfile_Column.getChildren().add(inputDate_HBox);

		// Hbox to create button for profile creation

		HBox CreateProfile_HBox = new HBox();
		CreateProfile_HBox.setPadding(new Insets(5, 0, 5, 0));
		Label inputLabel = new Label("");
		inputLabel.setMinWidth(160);
		inputLabel.setMinHeight(20);
		inputLabel.setAlignment(Pos.CENTER_RIGHT);
		inputLabel.setPadding(new Insets(0, 12, 0, 12));
		inputLabel.setStyle("-fx-font-weight: Bold");
		CreateProfilebtn = new Button("Next");
		CreateProfilebtn.setMinWidth(160);
		CreateProfilebtn.setAlignment(Pos.CENTER);
		CreateProfile_HBox.getChildren().add(inputLabel);
		CreateProfile_HBox.getChildren().add(CreateProfilebtn);
		createProfile_Column.getChildren().add(CreateProfile_HBox);


		
		
		
		
		// adds the vbox which all of the hbox's have been placed into & then put into
		// the stackpane

		createProfile_Content.getChildren().add(createProfile_Column);
		StackPane.setAlignment(createProfile_Column, Pos.CENTER_RIGHT);

		createProfileTab.setContent(createProfile_Content);

		// A new tab

		Tab selectModuleTab = new Tab();
		selectModuleTab.setText("Confirm Booking");
		selectModuleTab.setClosable(false);

		// flowpane instead of a stackpane so it doesn't stack

		FlowPane SelectModule = new FlowPane();
		SelectModule.setHgap(20);
		SelectModule.setVgap(20);
		SelectModule.setPrefWrapLength(600);
		SelectModule.setPadding(new Insets(20));

		VBox SelectModule_ColumnLeft = new VBox();
		SelectModule_ColumnLeft.setPrefSize(600, 600);
		SelectModule_ColumnLeft.setMinSize(600, 600);

		// Hbox same as last tab to put labels and textfeilds in place

		HBox TermOneModuleLabel_HBox = new HBox();
		TermOneModuleLabel_HBox.setPadding(new Insets(15, 20, 5, 30));
		Label TermOneModuleLabelOne = new Label("Available Times");
		TermOneModuleLabelOne.setAlignment(Pos.CENTER_RIGHT);
		TermOneModuleLabelOne.setPadding(new Insets(0, 12, 0, 12));
		TermOneModuleLabelOne.setStyle("-fx-font-weight: bold");
		Label TermOneModuleSelected = new Label("Time Selected");
		TermOneModuleSelected.setPadding(new Insets(0, 0, 0, 100));
		TermOneModuleSelected.setStyle("-fx-font-weight: bold");
		TermOneModuleLabel_HBox.getChildren().add(TermOneModuleLabelOne);
		TermOneModuleLabel_HBox.getChildren().add(TermOneModuleSelected);
		SelectModule_ColumnLeft.getChildren().add(TermOneModuleLabel_HBox);

		HBox TermOneModule_HBox = new HBox();
		TermOneModule_HBox.setPadding(new Insets(0, 30, 5, 30));
		TermOneModule_HBox.setSpacing(35);
		timeListView = new ListView<String>();
		timeListView.setMaxHeight(160);
		timeListView.setMinHeight(160);
		timeListView.setMinWidth(220);
		timeSelected = new ListView<String>();
		timeSelected.setMaxHeight(160);
		timeSelected.setMinHeight(160);
		timeSelected.setMinWidth(220);
		TermOneModule_HBox.getChildren().add(timeListView);
		TermOneModule_HBox.getChildren().add(timeSelected);
		SelectModule_ColumnLeft.getChildren().add(TermOneModule_HBox);

		HBox TermOneButtons_HBox = new HBox();
		TermOneButtons_HBox.setPadding(new Insets(0, 30, 20, 30));
		TermOneButtons_HBox.setSpacing(10);
		Label Term1 = new Label("");
		Term1.setAlignment(Pos.CENTER_RIGHT);
		Term1.setPadding(new Insets(10, 5, 10, 5));
		Term1.setStyle("-fx-font-weight: bold");
		selectTime = new Button("Select Time");
		selectTime.setMinWidth(75);
		selectTime.setAlignment(Pos.CENTER);
		selectTime.setPadding(new Insets(5, 12, 5, 12));
		removeTime = new Button("Change Time");
		removeTime.setAlignment(Pos.CENTER_LEFT);
		removeTime.setPadding(new Insets(5, 12, 5, 12));
		removeTime.setMinWidth(75);
		TermOneButtons_HBox.getChildren().add(Term1);
		TermOneButtons_HBox.getChildren().add(selectTime);
		TermOneButtons_HBox.getChildren().add(removeTime);
		SelectModule_ColumnLeft.getChildren().add(TermOneButtons_HBox);

		HBox TermTwoModuleLabel_HBox = new HBox();
		TermTwoModuleLabel_HBox.setPadding(new Insets(0, 20, 5, 30));
		TermTwoModuleLabel_HBox.setSpacing(20);
		Label TermTwoModuleLabelOne = new Label("Seating Preference");
		TermTwoModuleLabelOne.setAlignment(Pos.CENTER_RIGHT);
		TermTwoModuleLabelOne.setPadding(new Insets(0, 12, 0, 12));
		TermTwoModuleLabelOne.setStyle("-fx-font-weight: bold");
	
		
		

		HBox TermTwoModule_HBox = new HBox();

		seatSelectedListView = new ListView<String>();

		TermTwoModule_HBox.getChildren().add(seatSelectedListView);
		SelectModule_ColumnLeft.getChildren().add(TermTwoModule_HBox);

		HBox TermTwoButtons_HBox = new HBox();
		TermTwoButtons_HBox.setPadding(new Insets(0, 30, 20, 30));
		TermTwoButtons_HBox.setSpacing(10);
		Label Term2 = new Label("");
		Term2.setAlignment(Pos.CENTER_RIGHT);
		Term2.setPadding(new Insets(10, 5, 10, 5));
		Term2.setStyle("-fx-font-weight: bold");
		selectSeat = new Button("Select Seat");
		selectSeat.setMinWidth(75);
		selectSeat.setAlignment(Pos.CENTER);
		selectSeat.setPadding(new Insets(5, 12, 5, 12));
		seatRemove = new Button("Reset Seating");
		seatRemove.setAlignment(Pos.CENTER_LEFT);
		seatRemove.setPadding(new Insets(5, 12, 5, 12));
		seatRemove.setMinWidth(75);
		Label YearLongSelected = new Label("");
		YearLongSelected.setStyle("-fx-font-weight: bold");
		YearLongSelected.setPadding(new Insets(0, 10, 0, 60));
		TermTwoButtons_HBox.getChildren().add(Term2);
		TermTwoButtons_HBox.getChildren().add(selectSeat);
		TermTwoButtons_HBox.getChildren().add(seatRemove);
		TermTwoButtons_HBox.getChildren().add(YearLongSelected);
		SelectModule_ColumnLeft.getChildren().add(TermTwoButtons_HBox);


		HBox TimeOne_HBox = new HBox();
		TimeOne_HBox.setPadding(new Insets(0, 20, 0, 20));
		TimeOne_HBox.setSpacing(40);
		TimeOneTextField = new TextField();
		TimeOneTextField.setMaxWidth(50);
		TimeOneTextField.setAlignment(Pos.CENTER_RIGHT);
		TimeOneTextField.setEditable(false);
	
		SelectModule_ColumnLeft.getChildren().add(TimeOne_HBox);

		HBox SeatsTwo_HBox = new HBox();
		SeatsTwo_HBox.setPadding(new Insets(10, 20, 20, 20));
		SeatsTwo_HBox.setSpacing(40);
		SeatsTwoTextField = new TextField();
		SeatsTwoTextField.setMaxWidth(50);
		SeatsTwoTextField.setAlignment(Pos.CENTER_RIGHT);
		SeatsTwoTextField.setEditable(false);
		SubmitButton = new Button("Confirm Booking");
		SubmitButton.setMinWidth(75);
		SubmitButton.setPadding(new Insets(5, 12, 5, 12));
		SubmitButton.setAlignment(Pos.CENTER_LEFT);
		SeatsTwo_HBox.getChildren().add(SubmitButton);
		SelectModule_ColumnLeft.getChildren().add(SeatsTwo_HBox);

		SelectModule.getChildren().add(SelectModule_ColumnLeft);
		StackPane.setAlignment(SelectModule, Pos.CENTER_RIGHT);
		selectModuleTab.setContent(SelectModule);

		// tab to login/create account

		Tab moduleReserveTab = new Tab();
		moduleReserveTab.setText("Login/SignUp");
		moduleReserveTab.setClosable(false);

		StackPane ReviewModuleTab = new StackPane();
		VBox ReviewModuleTab_Column = new VBox();
		ReviewModuleTab_Column.setPrefSize(100, 100);

		HBox Login_HBox = new HBox();
		Login_HBox.setPadding(new Insets(5, 0, 5, 0));
		Label userLoginLabel = new Label("Username");
		userLoginLabel.setMinWidth(160);
		userLoginLabel.setMinHeight(20);
		userLoginLabel.setAlignment(Pos.CENTER);
		userLoginLabel.setPadding(new Insets(0, 12, 0, 12));
		userLoginLabel.setStyle("-fx-font-weight: Bold");
		TextField LoginTextField = new TextField();
		LoginTextField.setMinWidth(160);
		Login_HBox.getChildren().add(userLoginLabel);
		Login_HBox.getChildren().add(LoginTextField);
		ReviewModuleTab_Column.getChildren().add(Login_HBox);

		HBox Login_HBox1 = new HBox();
		Login_HBox.setPadding(new Insets(5, 0, 5, 0));
		Label userLoginLabel1 = new Label("Password");
		userLoginLabel1.setMinWidth(160);
		userLoginLabel1.setMinHeight(20);
		userLoginLabel1.setAlignment(Pos.CENTER);
		userLoginLabel1.setPadding(new Insets(0, 12, 0, 12));
		userLoginLabel1.setStyle("-fx-font-weight: Bold");
		TextField LoginTextField1 = new TextField();
		LoginTextField1.setMinWidth(160);
		Login_HBox1.getChildren().add(userLoginLabel1);
		Login_HBox1.getChildren().add(LoginTextField1);
		ReviewModuleTab_Column.getChildren().add(Login_HBox1);

		HBox LoginButton_HBox = new HBox();
		LoginButton_HBox.setPadding(new Insets(5, 0, 5, 0));
		Label inputLabel2 = new Label("");
		inputLabel2.setMinWidth(160);
		inputLabel2.setMinHeight(20);
		inputLabel2.setAlignment(Pos.CENTER_RIGHT);
		inputLabel2.setPadding(new Insets(0, 12, 0, 12));
		inputLabel2.setStyle("-fx-font-weight: Bold");
		LoginButton = new Button("Login");
		LoginButton.setMinWidth(160);
		LoginButton.setAlignment(Pos.CENTER);
		LoginButton_HBox.getChildren().add(inputLabel2);
		LoginButton_HBox.getChildren().add(LoginButton);
		ReviewModuleTab_Column.getChildren().add(LoginButton_HBox);
		
		
		HBox CreateButton_HBox = new HBox();
		CreateButton_HBox.setPadding(new Insets(5, 0, 5, 0));
		Label inputLabel3 = new Label("");
		inputLabel3.setMinWidth(160);
		inputLabel3.setMinHeight(20);
		inputLabel3.setAlignment(Pos.CENTER_RIGHT);
		inputLabel3.setPadding(new Insets(0, 12, 0, 12));
		inputLabel3.setStyle("-fx-font-weight: Bold");
		CreateAccButton = new Button("Create Account");
		CreateAccButton.setMinWidth(160);
		CreateAccButton.setAlignment(Pos.CENTER);
		CreateButton_HBox.getChildren().add(inputLabel3);
		CreateButton_HBox.getChildren().add(CreateAccButton);
		ReviewModuleTab_Column.getChildren().add(CreateButton_HBox);

		//

		// 2nd tab

		HBox unselectedReserveModule_HBox = new HBox();
		unselectedReserveModule_HBox.setPadding(new Insets(15, 20, 5, 30));
		unselectedReserveModule_HBox.setSpacing(20);
		Label unselectedReserveModule = new Label("Unselected Term 1 Modules");
		unselectedReserveModule.setAlignment(Pos.CENTER);
		unselectedReserveModule.setPadding(new Insets(0, 12, 0, 12));
		unselectedReserveModule.setStyle("-fx-font-weight: bold");
		Label selectedReserveModules = new Label("Term 1 Reserved Modules");
		selectedReserveModules.setPadding(new Insets(0, 0, 0, 100));
		selectedReserveModules.setStyle("-fx-font-weight: bold");
		// LoginTextField.getChildren().add(unselectedReserveModule_HBox);

		// login button

		SubmitReserveButton = new Button("Login");
		SubmitReserveButton.setAlignment(Pos.BOTTOM_CENTER);
		SubmitReserveButton.setPadding(new Insets(5, 12, 5, 12));
		SubmitReserveButton.setMinWidth(75);
		


		unselectedReserveModule_HBox.getChildren().add(SubmitReserveButton);

		ReviewModuleTab.getChildren().add(ReviewModuleTab_Column);
		StackPane.setAlignment(ReviewModuleTab, Pos.CENTER_LEFT);
		moduleReserveTab.setContent(ReviewModuleTab);
		
		//
		
		

		// CREATE ACCOUNT TAB

		Tab createAccTab = new Tab();
		createAccTab.setText("Create Account");
		createAccTab.setClosable(false);

		StackPane newAccTab = new StackPane();

		VBox newAcc_Column = new VBox();
		newAcc_Column.setPrefSize(600, 600);

		HBox CreateAcc_HBox = new HBox();
		CreateAcc_HBox.setPadding(new Insets(20, 20, 20, 20));
		TextField newAccTextField = new TextField();
		newAccTextField.setMinSize(560, 500);
		CreateAcc_HBox.getChildren().add(newAccTextField);
		newAcc_Column.getChildren().add(CreateAcc_HBox);

		HBox CreateAccButton_HBox = new HBox();
		CreateAccButton_HBox.setPadding(new Insets(0, 200, 0, 250));
		Button CreateOverview = new Button("Create");
		CreateAccButton_HBox.getChildren().add(CreateOverview);
		newAcc_Column.getChildren().add(CreateAccButton_HBox);

		newAccTab.getChildren().add(newAcc_Column);
		StackPane.setAlignment(newAccTab, Pos.CENTER_RIGHT);

		createAccTab.setContent(newAcc_Column);

		// MY ACCOUNT TAB

		Tab myAccTab = new Tab();
		myAccTab.setText("My Account");
		myAccTab.setClosable(false);

		StackPane myAcc = new StackPane();

		VBox myAcc_Column = new VBox();
		myAcc_Column.setPrefSize(600, 600);

		HBox MyAcc_HBox = new HBox();
		MyAcc_HBox.setPadding(new Insets(20, 20, 20, 20));
		TextField myAccTextField = new TextField();
		myAccTextField.setMinSize(560, 500);
		CreateAcc_HBox.getChildren().add(myAccTextField);
		myAcc_Column.getChildren().add(MyAcc_HBox);

		HBox myAccButton_HBox = new HBox();
		myAccButton_HBox.setPadding(new Insets(0, 200, 0, 250));
		Button myAccOverview = new Button("Create");
		CreateAccButton_HBox.getChildren().add(myAccOverview);
		myAcc_Column.getChildren().add(myAccButton_HBox);

		myAcc.getChildren().add(myAcc_Column);
		StackPane.setAlignment(myAcc, Pos.CENTER_RIGHT);

		createAccTab.setContent(myAcc);

		//

		Tab overviewSelectionTab = new Tab();
		overviewSelectionTab.setText("Confirmation Page");
		overviewSelectionTab.setClosable(false);

		StackPane OverViewTab = new StackPane();

		VBox OverviewTab_Column = new VBox();
		OverviewTab_Column.setPrefSize(600, 600);

		HBox Overview_HBox = new HBox();
		Overview_HBox.setPadding(new Insets(20, 20, 20, 20));
		TextField OverviewTextField = new TextField();
		OverviewTextField.setMinSize(560, 500);
		Overview_HBox.getChildren().add(OverviewTextField);
		OverviewTab_Column.getChildren().add(Overview_HBox);

		HBox OverviewButtom_HBox = new HBox();
		OverviewButtom_HBox.setPadding(new Insets(0, 200, 0, 250));
		Button SaveOverview = new Button("Exit");
		OverviewButtom_HBox.getChildren().add(SaveOverview);
		OverviewTab_Column.getChildren().add(OverviewButtom_HBox);

		OverViewTab.getChildren().add(OverviewTab_Column);
		StackPane.setAlignment(OverViewTab, Pos.CENTER_RIGHT);

		overviewSelectionTab.setContent(OverViewTab);

		// adds all of the tabs to the tabpane in the correct order

		tabPane.getTabs().add(createProfileTab);
		tabPane.getTabs().add(selectModuleTab);
		tabPane.getTabs().add(moduleReserveTab);
		tabPane.getTabs().add(createAccTab);
		tabPane.getTabs().add(myAccTab);
		tabPane.getTabs().add(overviewSelectionTab);

		this.setCenter(tabPane);
		
	}
	//

	// populates the combobox with the two options
	public void populateComboBox(Venue[] courses) {
		int courseCounter = courses.length - 1;

		while (courseCounter >= 0) {
			selectCourseComboBox.getItems().add(courses[courseCounter].getvenueName());
			courseCounter--;
		}
	}

	// attaching the event handling

	public void AttachEventHandlers(Venue[] courses)

	{

		// this button will take you to the next tab and will populate the boxes for the
		// times that was selected

		CreateProfilebtn.setOnMouseClicked(e -> {

			String selectedCourse = selectCourseComboBox.getSelectionModel().getSelectedItem();

			for (int iter = 0; iter < courses.length; iter++) {
				if (selectedCourse == courses[iter].getvenueName()) {
					timeListView.getItems().clear();
					timeSelected.getItems().clear();
					seatSelectedListView.getItems().clear();

					tabPane.getSelectionModel().select(1);

					ObservableList<Module> mods = FXCollections.observableArrayList(courses[iter].getModulesOnCourse());

					for (Iterator<Module> m = mods.iterator(); m.hasNext();) {
						Module mod = m.next();
						if (mod.getRunPlan() == Schedule.EVENING) {
							if (mod.isMandatory()) {
								timeSelected.getItems().add(mod.getModuleName());

							} else {
								timeListView.getItems().add(mod.getModuleName());
							}

						} else if (mod.getRunPlan() == Schedule.EVENING) {

						}
					}

				}
			}
			
			

		});

		// this will make the add button add the selected time to the next listview

		selectTime.setOnMouseClicked(e -> {

			timeListView.getSelectionModel().getSelectedIndex();

			String modName = timeListView.getItems().get(timeListView.getSelectionModel().getSelectedIndex());
			timeSelected.getItems().add(modName);
			timeListView.getItems().remove(timeListView.getSelectionModel().getSelectedIndex());

		});

		// this will make the remove button remove the selected time to the next
		// listview

		removeTime.setOnMouseClicked(e -> {

			timeSelected.getSelectionModel().getSelectedIndex();

			String modName = timeSelected.getItems().get(timeSelected.getSelectionModel().getSelectedIndex());
			timeListView.getItems().add(modName);
			timeSelected.getItems().remove(timeSelected.getSelectionModel().getSelectedIndex());

		});	
		

		SubmitButton.setOnMouseClicked(e -> {
			tabPane.getSelectionModel().select(5);
			
		});
		SubmitReserveButton.setOnMouseClicked(e -> {
			tabPane.getSelectionModel().select(4);
		});

		CreateAccButton.setOnMouseClicked(e -> {
			tabPane.getSelectionModel().clearAndSelect(3);
			
			
		});

		LoginButton.setOnMouseClicked(e -> {
			tabPane.getSelectionModel().clearAndSelect(4);
		});
	}

	@Override
	public void actionPerformed(ActionEvent e) {
		// TODO Auto-generated method stub
		
	}
			
	public Connection connect() {
		try {
			Class.forName("com.mysql.jdbc.Driver");
			return DriverManager.getConnection("jdbc:mysql://localhost:3306/booking", "root", "Arsenal123");
		} catch (SQLException | ClassNotFoundException e) {
			System.out.println(e);
			return null;
		}
}
	
		}

	
  

