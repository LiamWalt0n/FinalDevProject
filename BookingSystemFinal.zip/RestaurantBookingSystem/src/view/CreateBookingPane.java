package view;


import java.time.LocalDate;
import java.sql.*;
import java.util.Scanner;

import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.geometry.HPos;
import javafx.geometry.Pos;
import javafx.scene.control.Button;
import javafx.scene.control.ComboBox;
import javafx.scene.control.DatePicker;
import javafx.scene.control.Label;
import javafx.scene.control.TextField;
import javafx.scene.layout.ColumnConstraints;
import javafx.scene.layout.GridPane;
import javafx.scene.layout.HBox;
import model.Name;
import model.Venue;
import model.customerProfile;

public class CreateBookingPane extends GridPane {

	private ComboBox<Venue> cboTimes;
	private DatePicker inputDate;
	private TextField txtFirstName, txtSurname,  txtVenue, txtEmail, txtNumberOfPeople;
	private Button btnCreateBooking;
	
	
	// Scanner in = new Scanner(System.in);

	public CreateBookingPane() {
		//styling
		this.setVgap(15);
		this.setHgap(20);
		this.setAlignment(Pos.CENTER);

		ColumnConstraints column0 = new ColumnConstraints();
		column0.setHalignment(HPos.RIGHT);

		this.getColumnConstraints().addAll(column0);
		
		//create labels
		Label lblVenue = new Label("Venue: ");
		Label lblFirstName = new Label("Input first : ");
		Label lblSurname = new Label("Input surname: ");
		Label lblEmail = new Label("Input email: ");
		Label lblDate = new Label("Input date: ");
		Label lblNumberOfPeople = new Label("Number of people");
		
	
		
		//initialise combobox
		cboTimes = new ComboBox<Venue>(); //this is populated via method towards end of class
		
		//setup text fields
		txtFirstName = new TextField();
		txtSurname = new TextField();
		txtVenue = new TextField();
		txtEmail = new TextField();
		txtNumberOfPeople = new TextField();
		
		
		inputDate = new DatePicker();
		
		//initialise create profile button
		btnCreateBooking = new Button("Create Booking");
		
		

		//add controls and labels to container
		this.add(lblVenue, 0, 0);
		this.add(cboTimes, 1, 0);
		
		this.add(lblFirstName, 0, 2);
		this.add(txtFirstName, 1, 2);

		this.add(lblSurname, 0, 3);
		this.add(txtSurname, 1, 3);
		
		this.add(lblEmail, 0, 4);
		this.add(txtEmail, 1, 4);
		
		this.add(lblDate, 0, 5);
		this.add(inputDate, 1, 5);
		
		this.add(lblNumberOfPeople, 0, 6);
		this.add(txtNumberOfPeople, 1, 6);
			
		this.add(new HBox(), 0, 6);
		this.add(btnCreateBooking, 1, 6);
	}
	
	//method to allow the controller to add courses to the combobox
	public void addTimeToComboBox(Venue[] courses) {
		cboTimes.getItems().addAll(courses);
		cboTimes.getSelectionModel().select(0); //select first course by default
	}
	
	//methods to retrieve the form selection/input
	public Venue getSelectedVenue() {
		return cboTimes.getSelectionModel().getSelectedItem();
	}
	
	public String getVenuenumber() {
		return txtVenue.getText();
	}
	

	public String getEmail() {
		return txtEmail.getText();
	}
	
	public LocalDate getDate() {
		return inputDate.getValue();
	}
	
	
	//method to attach the create the profile button event handler
	public void addCreateBookingHandler(EventHandler<ActionEvent> handler) {
		btnCreateBooking.setOnAction(handler);
	}
	
		

}
