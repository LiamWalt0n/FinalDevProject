package controller;


import model.Venue;
import model.customerProfile;
import model.Schedule;

import java.awt.event.ActionEvent;
import java.beans.Statement;
import java.sql.Connection;

import javax.swing.JFrame;
import javax.swing.JOptionPane;

import model.Module;
import model.Name;
import view.ConfirmBookingRootPane;



public class BookingSystemController {
	
	 private static JFrame parentJFrame;

	//fields to be used throughout the class
	private ConfirmBookingRootPane view;

	private customerProfile model;

	public BookingSystemController(ConfirmBookingRootPane view, customerProfile model) {
		//initialise model and view fields
		this.model = model;
		this.view = view;

		//populate combobox in create profile pane, e.g. if cpp represented your create profile pane you could invoke the line below
		//cpp.populateComboBox(setupAndGetCourses());

		view.populateComboBox(setupAndGetVenues());
		
		//attach event handlers to view using private helper method
		this.attachEventHandlers();	

	}

	private void attachEventHandlers() {
		Venue[] mealInfo = setupAndGetVenues();
		
		view.AttachEventHandlers(mealInfo);
		
	
	}


	private Venue[] setupAndGetVenues() {
		Module dinner = new Module("TIME1", "15:00", 0, false, Schedule.EVENING);
		Module dinner1 = new Module("TIME2", "15:15", 0, false, Schedule.EVENING);
		Module dinner2 = new Module("TIME3", "15:30", 0, false, Schedule.EVENING);	
		Module dinner3 = new Module("TIME4", "15:45", 0, false, Schedule.EVENING);
		Module dinner4 = new Module("TIME5", "16:00", 0, false, Schedule.EVENING);
		Module dinner5 = new Module("TIME6", "16:15", 0, false, Schedule.EVENING);	
		Module dinner6 = new Module("TIME7", "16:30", 0, false, Schedule.EVENING);	
		Module dinner7 = new Module("TIME8", "16:45", 0, false, Schedule.EVENING);
		Module dinner8 = new Module("TIME9", "17:00", 0, false, Schedule.EVENING);
		Module dinner9 = new Module("TIME10", "17:15", 0, false, Schedule.EVENING);
		Module dinner10 = new Module("TIME11", "17:30", 0, false, Schedule.EVENING);
		Module dinner11 = new Module("TIME12", "17:45", 0, false, Schedule.EVENING);
		Module dinner12 = new Module("TIME13", "18:00", 0, false, Schedule.EVENING);
		Module dinner13 = new Module("TIME14", "18:15", 0, false, Schedule.EVENING);
		Module dinner14 = new Module("TIME15", "18:30", 0, false, Schedule.EVENING);
		Module dinner15 = new Module("TIME16", "18:45", 0, false, Schedule.EVENING);
		Module dinner16 = new Module("TIME17", "19:00", 0, false, Schedule.EVENING);
		Module dinner17 = new Module("TIME18", "19:15", 0, false, Schedule.EVENING);

		Venue londonDinner = new Venue("London");
		londonDinner.addModule(dinner);
		londonDinner.addModule(dinner1);
		londonDinner.addModule(dinner2);
		londonDinner.addModule(dinner3);
		londonDinner.addModule(dinner4);
		londonDinner.addModule(dinner5);
		londonDinner.addModule(dinner6);
		londonDinner.addModule(dinner7);
		londonDinner.addModule(dinner8);
		londonDinner.addModule(dinner9);
		londonDinner.addModule(dinner10);
		londonDinner.addModule(dinner11);
		londonDinner.addModule(dinner12);
		londonDinner.addModule(dinner13);
		londonDinner.addModule(dinner14);
		londonDinner.addModule(dinner15);
		londonDinner.addModule(dinner16);
		londonDinner.addModule(dinner17);


		Venue birminghamDinner = new Venue("Birmingham");
		birminghamDinner.addModule(dinner);
		birminghamDinner.addModule(dinner1);
		birminghamDinner.addModule(dinner2);
		birminghamDinner.addModule(dinner3);
		birminghamDinner.addModule(dinner4);
		birminghamDinner.addModule(dinner5);
		birminghamDinner.addModule(dinner6);
		birminghamDinner.addModule(dinner7);
		birminghamDinner.addModule(dinner8);
		birminghamDinner.addModule(dinner9);
		birminghamDinner.addModule(dinner10);
		birminghamDinner.addModule(dinner11);
		birminghamDinner.addModule(dinner12);
		birminghamDinner.addModule(dinner13);
		birminghamDinner.addModule(dinner14);
		birminghamDinner.addModule(dinner15);
		birminghamDinner.addModule(dinner16);
		birminghamDinner.addModule(dinner17);
		
		Venue[] courses = new Venue[2];
		courses[0] = londonDinner;
		courses[1] = birminghamDinner;

		return courses;
	}
	
	}



