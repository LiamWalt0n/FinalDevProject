package model;

import java.util.Collection;
import java.util.HashMap;
import java.util.Map;


public class Venue{
	
	private String venueName;
	private Map<String, Module> times;
	
	public Venue(String venueName) {
		this.venueName = venueName;
		times = new HashMap<String, Module>();
	}
	
	public String getvenueName() {
		return venueName;
	}
	
	public void setName(String name) {
		venueName = name;
	}
	
	public void addModule(Module m) {
		times.put(m.getModuleCode(), m);
	}
	
	public Module getModuleByCode(String code) {
		return times.get(code);
	}
	
	public Collection<Module> getModulesOnCourse() {
		return times.values();
	}
	
	@Override
	public String toString() {
		//a non-standard toString that simply returns the venue name,
		//so as to assist in displaying courses correctly in a ComboBox<Venue>
		return venueName;
	}
	
	public String actualToString() {
		return "Venue:[venueName=" + venueName + ", times=" + times + "]";
	}
	
}
