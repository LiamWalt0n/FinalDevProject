package model;

public enum Schedule {
	EVENING
}
