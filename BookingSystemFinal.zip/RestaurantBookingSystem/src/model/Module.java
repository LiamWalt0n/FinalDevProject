package model;

import java.util.Objects;


public class Module implements Comparable<Module> {
	
	private String venueCode;
	private String venueName;
	private int credits;
	private boolean nonOptional;
	private Schedule runPlan;
	
	public Module(String venueCode, String venueName, int credits, boolean mandatory, Schedule runPlan) {
		this.venueCode = venueCode;
		this.venueName = venueName;
		this.credits = credits;
		this.nonOptional = nonOptional;
		this.runPlan = runPlan;
	}

	public String getModuleCode() {
		return venueCode;
	}

	public void setVenueCode(String venueCode) {
		this.venueCode = venueCode;
	}

	public String getModuleName() {
		return venueName;
	}

	public void setModuleName(String venueName) {
		this.venueName = venueName;
	}

	public int getCredits() {
		return credits;
	}
	
	public void setCredits(int credits) {
		this.credits = credits;
	}

	public boolean isMandatory() {
		return nonOptional;
	}
	
	public void setMandatory(boolean mandatory) {
		this.nonOptional = mandatory;
	}
	
	public Schedule getRunPlan() {
		return runPlan;
	}

	public void setRunPlan(Schedule runPlan) {
		this.runPlan = runPlan;
	}
	
	
	@Override
	public String toString() {
		//a non-standard toString that simply returns the venue and name,
		//so as to assist in displaying times correctly in a ListView<Module> in the view
		//-Note- you may customise this if you wish to do so.
		return venueCode + " : " + venueName;
	}
	
	public String actualToString() {
		return "Module:[venueCode=" + venueCode + ", venueName=" + venueName + 
				", credits=" + credits + ", nonOptional=" + nonOptional + ", runPlan=" + runPlan + "]";
	}
	
	@Override
	public int compareTo(Module other) {
		int result = this.venueCode.compareTo(other.venueCode);
		
		if (result == 0) {
			result = Integer.compare(this.credits, other.credits);
			
			if (result == 0) {
				result = Boolean.compare(other.nonOptional, this.nonOptional);
				
				if (result == 0) {
					result = this.venueName.compareTo(other.venueName);
					
					if (result == 0) {
						result = this.runPlan.compareTo(other.runPlan);
					}
				}
				
			}
		}
		
		return result;
	}
	
	@Override
	public boolean equals(Object obj) {
		if (obj == null || obj.getClass() != this.getClass())
			return false;
		
		Module other = (Module) obj;
		
		return this.nonOptional == other.nonOptional && this.credits == other.credits &&
				this.venueCode.equals(other.venueCode) && this.venueName.equals(other.venueName) &&
				this.runPlan.equals(other.runPlan);
		
	}
	
	@Override
	public int hashCode() {
		return Objects.hash(nonOptional, credits, venueCode, venueName, runPlan);
	}
	
	
}
