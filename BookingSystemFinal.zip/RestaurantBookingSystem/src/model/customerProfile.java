package model;

import java.time.LocalDate;
import java.util.Set;
import java.util.TreeSet;



public class customerProfile {

	private String venue;
	private Name customerName;
	private String email;
	private LocalDate date;
	private Venue time;
	private Set<Module> selectedModules;
	
	
	// default constructor
	public customerProfile() {
		venue = "";
		customerName = new Name();
		email = "";
		date = null;
		time = null;
		selectedModules = new TreeSet<Module>();
	}
	
	public String getvenue() {
		return venue;
	}
	
	public void setvenue(String venue) {
		this.venue = venue;
	}
	
	public Name getCustomerName() {
		return customerName;
	}
	
	public void setcustomerName(Name customerName) {
		this.customerName = customerName;
	}
	
	public String getEmail() {
		return email;
	}
	
	public void setEmail(String email) {
		this.email = email;
	}
	
	public LocalDate getDate() {
		return date;
	}
	
	public void setDate(LocalDate date) {
		this.date = date;
	}
	
	public Venue getTime() {
		return time;
	}
	
	public void settime(Venue time) {
		this.time = time;
	}
	
	public boolean addSelectedModule(Module m) {
		return selectedModules.add(m);
	}
	
	public Set<Module> getSelectedModules() {
		return selectedModules;
	}
	
	public void clearSelectedModules() {
		selectedModules.clear();
	}
	
	@Override
	public String toString() {
		return "CustomerProfile:[venuer=" + venue + ", customerName="
				+ customerName + ", email=" + email + ", date="
				+ date + ", course=" + time.actualToString() 
				+ ", selectedModules=" + selectedModules + "]";
	}
	
}
